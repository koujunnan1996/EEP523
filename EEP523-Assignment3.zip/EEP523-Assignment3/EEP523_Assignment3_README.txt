Junnan Kou <jk257@uw.edu> 

Pull-UP Counter - This is an app that apply the Accelerometer and Gyroscope to detect the shake motion of the phone. After you shake the phone, the pull-up detector will be actived so that you can count and record the number of the pull-ups.

Instruction:
When you enter the app, you will see that the main interface has two modes for recording the number of pull-ups, One is Customize model and the ohter is Free model, only if you shake the phone and the shake is detected, (I set a ringtone when the first shake was detected on main page to remind you the counter can work from now！！) you can access the model you want.

when you open customize model, if you do not define the number and do the pull-up motion, there will be a reminder to let you set the initial number.
