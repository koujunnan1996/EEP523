﻿Junnan Kou <jk257@uw.edu> 

TheftDetector - This is an app that can be connected with the Arduino microcontrollor that detect whether there is a theft open your door.

Caution:
1.Sometimes it may take a long time to connect the App with arduino.
2.Beacause the sensor is particularly sensitive so the user should use it carefully.
3.The circuit playground should be placed vertically with Micro-B USB Jack up!!!!!!!

