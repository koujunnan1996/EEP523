Junnan Kou <jk257@uw.edu> 

Swap face - This is an app that can detect the face region in a picture. It not only allows you to swap the face between two different pictures but also make a blurred face on the original picture. And you can also draw something on the picture that you take or you choose.

Caution:
Once you choose to take a photo or choose a photo, you must wait for about 5 ~ 10 seconds to wait for the image to be uploaded and loaded on the phone. There will be a text prompt at the bottom of the phone screen, such as "image1 uploaded", "image2 uploaded" and "open your eye and take a new picture" etc.
ONLY you see the text. You can use Swap faces and blur ONLY when you see these texts on the screen while meaning these pictures have been detected and loaded successfully