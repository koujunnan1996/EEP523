Name: Junnan Kou
Email address: <jk257@uw.edu>

TicTacToe -- This app is a interesting game that the object of Tic Tac Toe is to get three in a row. You play on a three by three game board. The first player can choose the icon as X or O then the second player is O or X. If the player does not choose the icon and start the game directly Then player_1 will choose icon randomly,the Players alternate placing Xs and Os on the game board until either oppent has three in a row or all nine squares are filled. If one side's winning streak is ended, the first order of the new game will be exchanged. In the event that no one has three in a row, the stalemate is called a cat game.


