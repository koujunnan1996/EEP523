package com.example.tictactoe

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private var button_Instruction: Button? = null
    private var button_Start: Button? = null
    private var button_choose: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        button_Start = findViewById<View>(R.id.Start_Game) as Button
        button_Start!!.setOnClickListener { GameStart() }
        button_choose = findViewById<View>(R.id.Player_choose) as Button
        button_choose!!.setOnClickListener { PlayerChoose() }
        button_Instruction = findViewById<View>(R.id.game_instruction) as Button
        button_Instruction!!.setOnClickListener { ShowInstruction() }
    }

    fun GameStart() {
        val intent2 = Intent(this, MainActivity2::class.java)
        startActivity(intent2)
    }

    fun PlayerChoose() {
        val intent = Intent(this, MainActivity3::class.java)
        startActivity(intent)
    }

    fun ShowInstruction() {
        val intent3 = Intent(this, Main4Activity::class.java)
        startActivity(intent3)
    }

    companion object {
        @JvmField
        var playerTurn = false
    }
}