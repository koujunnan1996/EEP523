package com.example.tictactoe

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity2 : AppCompatActivity(), View.OnClickListener {
    private val buttons = Array(3) { arrayOfNulls<Button>(3) }
    private var winFlag = false
    private var roundCount = 0
    private var player_1points = 0
    private var player_2points = 0
    private var textViewPlayer1: TextView? = null
    private var textViewPlayer2: TextView? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
        winFlag = if (MainActivity.playerTurn) {
            true
        } else {
            false
        }
        textViewPlayer1 = findViewById(R.id.text_view_p1)
        textViewPlayer2 = findViewById(R.id.text_view_p2)
        for (i in 0..2) {
            for (j in 0..2) {
                val buttonID = "button_$i$j"
                val resID = resources.getIdentifier(buttonID, "id", packageName)
                buttons[i][j] = findViewById(resID)
                buttons[i][j]?.setOnClickListener(this)
            }
        }
        val buttonReset = findViewById<Button>(R.id.button_restart)
        buttonReset.setOnClickListener { GameRestart() }

        val buttonExit = findViewById<Button>(R.id.button_exit)
        buttonExit.setOnClickListener { GameOver() }
    }

    override fun onClick(v: View) {
        if ((v as Button).text.toString() != "") {
            return
        }
        if (MainActivity.playerTurn) {
            v.text = "X"
        } else {
            v.text = "O"
        }
        roundCount++
        if (checkWin()) {
            if (MainActivity.playerTurn == winFlag) {
                player1Win()
            } else {
                player2Win()
            }
        } else if (roundCount == 9) {
            NoWinner()
        } else {
            MainActivity.playerTurn = !MainActivity.playerTurn
        }
    }

    private fun checkWin(): Boolean {
        val chessBoard = Array(3) { arrayOfNulls<String>(3) }
        for (i in 0..2) {
            for (j in 0..2) {
                chessBoard[i][j] = buttons[i][j]!!.text.toString()
            }
        }
        for (i in 0..2) {
            if (chessBoard[i][0] == chessBoard[i][1] && chessBoard[i][0] == chessBoard[i][2] && chessBoard[i][0] != "") {
                return true
            }
        }
        for (i in 0..2) {
            if (chessBoard[0][i] == chessBoard[1][i] && chessBoard[0][i] == chessBoard[2][i] && chessBoard[0][i] != "") {
                return true
            }
        }
        if (chessBoard[0][0] == chessBoard[1][1] && chessBoard[0][0] == chessBoard[2][2] && chessBoard[0][0] != "") {
            return true
        }
        return if (chessBoard[0][2] == chessBoard[1][1] && chessBoard[0][2] == chessBoard[2][0] && chessBoard[0][2] != "") {
            true
        } else false
    }

    private fun player1Win() {
        player_1points++
        Toast.makeText(this, "player 1 win !", Toast.LENGTH_SHORT).show()
        changePoints()
        reset()
    }

    private fun player2Win() {
        player_2points++
        Toast.makeText(this, "player 2 win !", Toast.LENGTH_SHORT).show()
        changePoints()
        reset()
    }

    private fun NoWinner() {
        Toast.makeText(this, "No winner !", Toast.LENGTH_SHORT).show()
        reset()
    }

    private fun changePoints() {
        textViewPlayer1!!.text = "Player 1's score : $player_1points"
        textViewPlayer2!!.text = "Player 2's score : $player_2points"
    }

    private fun reset() {
        for (i in 0..2) {
            for (j in 0..2) {
                buttons[i][j]!!.text = ""
            }
        }
        roundCount = 0
        //MainActivity.playerTurn = true;
    }

    private fun GameRestart() {
        player_1points = 0
        player_2points = 0
        changePoints()
        reset()
    }

    fun GameOver() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("roundCount", roundCount)
        outState.putInt("player_1points", player_1points)
        outState.putInt("player_2points", player_2points)
        outState.putBoolean("player_1Turn", MainActivity.playerTurn)
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        roundCount = savedInstanceState.getInt("roundCount")
        player_1points = savedInstanceState.getInt("player_1points")
        player_2points = savedInstanceState.getInt("player_2points")
        MainActivity.playerTurn = savedInstanceState.getBoolean("player_1Trun")
    }
}