Junnan Kou <jk257@uw.edu> 

Custom Gesture Recognition App – This is an App that can detect gestures performed by the smartphone and captured with the accelerometer sensor. in the original model we can detect the "wing" movement and label 0 represent wing, label 1 represent no recognized gesture.

Caution:Because data is collected at a fixed frequency of 25 Hz, it will take about 5 seconds to collect data and make predictions after clicking the button. In my app, if you click prediction, the screen will show a text that: "data collecting", when the data capture finished, the result will display and the text on screen will become"collection complete" to tell user the process is done! 